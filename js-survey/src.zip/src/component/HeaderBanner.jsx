const HeaderBanner = () => (
  <header className="bg-blue-600 text-white p-6 text-center text-3xl font-bold shadow-md">
    Jan Suraaj Aantirik Survey
  </header>
);

export default HeaderBanner;
