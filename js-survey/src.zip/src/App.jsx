import React, { useState, useEffect } from "react";
import HeaderBanner from "./component/HeaderBanner";
import UserForm from "./component/UserForm";
import DistrictSelector from "./component/DistrictSelector";
import RatingQuestions from "./component/RatingQuestions";
import MCQQuestions from "./component/MCQQuestions";
import Notification from "./component/Notification"; // see previous answer for code
import surveyQuestions from "./Resource/survey_questions.json";
import mcqQuestions from "./Resource/mcq_questions.json";

function App() {
  const [user, setUser] = useState({ name: "", phone: "" });
  const [geo, setGeo] = useState({ district: "", assembly: "" });
  const [ratings, setRatings] = useState({});
  const [mcqs, setMcqs] = useState({});
  const [errors, setErrors] = useState({});
  const [notification, setNotification] = useState(null);

  // Error clearing helpers
  const clearErrorForField = (fieldKey) => {
    setErrors((prev) => {
      const newErrors = { ...prev }
      delete newErrors[fieldKey]
      return newErrors
    })
  }

  // On Input Change Handlers
  const handleUserChange = (field, value) => {
    setUser((prev) => ({ ...prev, [field]: value }));
    clearErrorForField(field);
  };

  const handleGeoChange = (field, value) => {
    setGeo((prev) => ({ ...prev, [field]: value }));
    clearErrorForField(field);
  };

  const handleRatingsChange = (answers) => {
    setRatings(answers);
    Object.keys(answers).forEach((id) => clearErrorForField(`rating_${id}`));
  };

  const handleMCQChange = (answers) => {
    setMcqs(answers);
    Object.keys(answers).forEach((id) => clearErrorForField(`mcq_${id}`));
  };

  // Validation
  const validateAll = () => {
    const errs = {};
    // User validation
    if (!user.name.trim()) errs.name = "Name is required";
    if (!user.phone.trim()) errs.phone = "Phone number is required";
    else if (!/^\d{10}$/.test(user.phone)) errs.phone = "Phone number must be 10 digits";
    // Geo validation
    if (!geo.district) errs.district = "District is required";
    if (!geo.assembly) errs.assembly = "Assembly is required";
    // Ratings and MCQ
    surveyQuestions.forEach((q) => {
      if (!ratings[q.id]) errs[`rating_${q.id}`] = "Please select rating";
    });
    mcqQuestions.forEach((q) => {
      if (!mcqs[q.id]) errs[`mcq_${q.id}`] = "Please select an option";
    });
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  // Reset form for new entry
  const clearAllFields = () => {
    setUser({ name: "", phone: "" });
    setGeo({ district: "", assembly: "" });
    setRatings({});
    setMcqs({});
  };

  // Submit handler
  const handleSubmit = (e) => {
    e.preventDefault();
    if (validateAll()) {
      setNotification({
        type: "success",
        message: "Survey submitted successfully",
      });
      console.log("Submitted data:", { user, geo, ratings, mcqs });
      clearAllFields();
    } else {
      setNotification({
        type: "error",
        message: "Failed to submit data"
      });
    }
  };

  // Auto-dismiss notification after 3.5s
  useEffect(() => {
    if (notification) {
      const timer = setTimeout(() => setNotification(null), 3500);
      return () => clearTimeout(timer);
    }
  }, [notification]);

  return (
    <div className="min-h-screen bg-[rgb(247,199,27)] p-4">
      <HeaderBanner />
      {notification && (
        <Notification
          {...notification}
          onClose={() => setNotification(null)}
        />
      )}
      <form
        onSubmit={handleSubmit}
        className="max-w-4xl mx-auto mt-8 space-y-6"
        noValidate
      >
        <UserForm values={user} onUserChange={handleUserChange} errors={errors} />
        <DistrictSelector values={geo} onDistrictChange={handleGeoChange} errors={errors} />
        <RatingQuestions values={ratings} onRatingChange={handleRatingsChange} errors={errors} />
        <MCQQuestions values={mcqs} onMCQChange={handleMCQChange} errors={errors} />
        <div className="text-center pt-2">
          <button
            type="submit"
            className="px-8 py-2 bg-blue-600 text-white font-semibold rounded-md hover:bg-blue-700 transition"
          >
            Submit Survey
          </button>
        </div>
      </form>
    </div>
  );
}

export default App;
